# The GirlsWhoCode CQY Chapter from Spring 2017

This is the website we have built, College Classified.
Functionality it will have :
- [ ] Ability to Search for Colleges
- [ ] A Calendar to Keep Track of Deadlines
- [ ] Quizzes to find College Fit
- [ ] About Us page
- [ ] Scholarship Information
